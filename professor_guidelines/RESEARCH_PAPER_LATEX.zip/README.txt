Compile RESEARCH_PAPER.tex with pdfLaTeX twice, or upload this ZIP to Overleaf.
IEEEtran conference mode, A4; author and faculty-guide details are from the supplied project cover.
Author and faculty-guide emails were supplied by the user; no corresponding author is designated.
Venue-specific submission metadata has not been supplied.
IEEEtran is unmodified; original license/support text is included.
